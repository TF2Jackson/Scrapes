The Natural Language Toolkit (NLTK) is a Python package for
natural language processing.  NLTK requires Python 2.7, 3.5, 3.6, or 3.7.

